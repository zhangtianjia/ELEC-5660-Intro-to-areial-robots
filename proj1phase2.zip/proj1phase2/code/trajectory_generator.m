function s_des = trajectory_generator(t, path, h)


if nargin > 1 % pre-process can be done here (given waypoints)

else % output desired trajectory here (given time)
    
end

end


